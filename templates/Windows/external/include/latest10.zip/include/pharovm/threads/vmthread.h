#ifndef __VM_THREAD__
#define __VM_THREAD__

#endif // ifndef __VM_THREAD__